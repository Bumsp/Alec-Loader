cheat made by outspect.
bypass put together by aelx.

to launch the anticheat bypass run "Run.bat" and select "Anitcheat Bypass".

to launch the cheat run "Run.bat" then select "Anticheat bypass" (if you haven't already or you still get kicked) then select "Cheat".

When attempting to bypass; If it says "The system cannot find the file specified." Go to the "Extra" Folder, copy the "1v1.dll" and move it into this folder. //MAKE SURE THE NAME IS STILL "1v1.dll" AND NOT "1v1.dll -Copy" IMPORTANT!!!

^OR YOU CAN REDOWNLOAD THIS WHOLE CHEAT/BYPASS